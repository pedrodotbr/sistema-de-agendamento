import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useToast } from '@/components/ui/use-toast';
import Header from '@/components/Header';
import BookingForm from '@/components/BookingForm';
import BookingsTable from '@/components/BookingsTable';

const proatisByPeriod = {
  'Manhã': 'Pedro',
  'Tarde': 'Ana Paula',
  'Noite': 'Renan',
};

const App = () => {
  const { toast } = useToast();
  const [bookings, setBookings] = useState([]);
  
  const [formData, setFormData] = useState({
    teacherName: '',
    subject: '',
    equipmentType: '',
    equipmentQuantity: 1,
    date: '',
    period: '',
    classTimes: [],
    proati: '',
  });

  useEffect(() => {
    try {
      const storedBookings = localStorage.getItem('bookings');
      if (storedBookings) {
        let bookingsData = JSON.parse(storedBookings);
        bookingsData = bookingsData.map(booking => {
          if (booking.classTime && !Array.isArray(booking.classTimes)) {
            const { classTime, ...rest } = booking;
            return { ...rest, classTimes: [classTime] };
          }
          if (!booking.classTimes) {
            return { ...booking, classTimes: [] };
          }
          return booking;
        });
        setBookings(bookingsData);
      }
    } catch (error) {
      console.error("Failed to parse or migrate bookings from localStorage", error);
      setBookings([]);
    }
  }, []);

  useEffect(() => {
    try {
        localStorage.setItem('bookings', JSON.stringify(bookings));
    } catch (error) {
        console.error("Failed to save bookings to localStorage", error);
    }
  }, [bookings]);

  const handleInputChange = (field, value) => {
    const newFormData = { ...formData, [field]: value };
    if (field === 'period') {
      newFormData.proati = proatisByPeriod[value] || '';
    }
    setFormData(newFormData);
  };
  
  const handleClassTimeChange = (classTime) => {
    const currentClassTimes = formData.classTimes;
    const newClassTimes = currentClassTimes.includes(classTime)
      ? currentClassTimes.filter(time => time !== classTime)
      : [...currentClassTimes, classTime];
    newClassTimes.sort((a,b) => a - b);
    handleInputChange('classTimes', newClassTimes);
  };

  const resetForm = () => {
    setFormData({
      teacherName: '',
      subject: '',
      equipmentType: '',
      equipmentQuantity: 1,
      date: '',
      period: '',
      classTimes: [],
      proati: '',
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const { teacherName, subject, equipmentType, date, period, classTimes } = formData;

    if (!teacherName || !subject || !equipmentType || !date || !period || classTimes.length === 0) {
      toast({
        title: 'Erro de Validação',
        description: 'Por favor, preencha todos os campos obrigatórios.',
        variant: 'destructive',
      });
      return;
    }

    const isConflict = bookings.some(booking => 
      booking.date === date && 
      booking.period === period && 
      booking.classTimes.some(bookedTime => classTimes.includes(bookedTime))
    );

    if (isConflict) {
      toast({
        title: 'Horário Indisponível',
        description: 'Uma ou mais aulas selecionadas já foram agendadas. Por favor, revise sua seleção.',
        variant: 'destructive',
      });
      return;
    }

    const newBooking = { id: Date.now(), ...formData };
    setBookings([...bookings, newBooking].sort((a, b) => new Date(a.date) - new Date(b.date) || a.period.localeCompare(b.period) || (a.classTimes[0] || 0) - (b.classTimes[0] || 0)));
    resetForm();

    toast({
      title: 'Agendamento Realizado!',
      description: 'Seu equipamento foi agendado com sucesso.',
    });
  };

  const deleteBooking = (id) => {
    setBookings(bookings.filter((booking) => booking.id !== id));
    toast({
      title: 'Agendamento Removido',
      description: 'O agendamento foi excluído com sucesso.',
    });
  };

  return (
    <>
      <Helmet>
        <title>Agendamento de Equipamentos Tech</title>
        <meta name="description" content="Sistema inteligente para agendamento de equipamentos de tecnologia para uso educacional." />
      </Helmet>
      <div className="min-h-screen w-full relative flex flex-col items-center p-4 sm:p-6 lg:p-8">
        <Header />
        <main className="grid grid-cols-1 lg:grid-cols-5 gap-8 w-full max-w-7xl mx-auto">
          <BookingForm
            formData={formData}
            handleInputChange={handleInputChange}
            handleClassTimeChange={handleClassTimeChange}
            handleSubmit={handleSubmit}
          />
          <BookingsTable
            bookings={bookings}
            deleteBooking={deleteBooking}
          />
        </main>
      </div>
    </>
  );
};

export default App;