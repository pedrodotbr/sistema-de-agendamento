import React from 'react';
import { motion } from 'framer-motion';
import { PlusCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Checkbox } from '@/components/ui/checkbox';

const BookingForm = ({ formData, handleInputChange, handleClassTimeChange, handleSubmit }) => {
  return (
    <motion.div
      initial={{ opacity: 0, x: -50 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.7, delay: 0.2 }}
      className="lg:col-span-2"
    >
      <Card>
        <CardHeader>
          <CardTitle>Novo Agendamento</CardTitle>
          <CardDescription>Preencha os dados para reservar os equipamentos.</CardDescription>
        </CardHeader>
        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="teacherName">Professor</Label>
                <Input id="teacherName" value={formData.teacherName} onChange={(e) => handleInputChange('teacherName', e.target.value)} placeholder="Seu nome" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="subject">Disciplina</Label>
                <Input id="subject" value={formData.subject} onChange={(e) => handleInputChange('subject', e.target.value)} placeholder="Sua disciplina" />
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="equipmentType">Equipamento</Label>
                <Select onValueChange={(value) => handleInputChange('equipmentType', value)} value={formData.equipmentType}>
                  <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Netbook">Netbook</SelectItem>
                    <SelectItem value="Tablet">Tablet</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="equipmentQuantity">Quantidade</Label>
                <Input id="equipmentQuantity" type="number" min="1" max="35" value={formData.equipmentQuantity} onChange={(e) => handleInputChange('equipmentQuantity', e.target.value)} />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="date">Data</Label>
              <Input id="date" type="date" value={formData.date} onChange={(e) => handleInputChange('date', e.target.value)} />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="period">Período</Label>
                <Select onValueChange={(value) => handleInputChange('period', value)} value={formData.period}>
                  <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Manhã">Manhã</SelectItem>
                    <SelectItem value="Tarde">Tarde</SelectItem>
                    <SelectItem value="Noite">Noite</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Aulas</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left font-normal">
                      {formData.classTimes.length > 0
                        ? formData.classTimes.map(t => `${t}ª`).join(', ')
                        : "Selecione as aulas"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <div className="p-2 space-y-1">
                      {Array.from({ length: 7 }, (_, i) => String(i + 1)).map(n => (
                        <div key={n} className="flex items-center space-x-2 p-1 rounded-md hover:bg-slate-800">
                          <Checkbox
                            id={`class-${n}`}
                            checked={formData.classTimes.includes(n)}
                            onCheckedChange={() => handleClassTimeChange(n)}
                          />
                          <Label htmlFor={`class-${n}`} className="w-full cursor-pointer">{n}ª Aula</Label>
                        </div>
                      ))}
                    </div>
                  </PopoverContent>
                </Popover>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="proati">Proati Responsável</Label>
              <Input id="proati" value={formData.proati} readOnly placeholder="Selecione um período" className="bg-slate-800/80" />
            </div>
          </CardContent>
          <CardFooter>
            <Button type="submit" className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-bold shadow-lg">
              <PlusCircle className="mr-2 h-4 w-4" /> Agendar Agora
            </Button>
          </CardFooter>
        </form>
      </Card>
    </motion.div>
  );
};

export default BookingForm;