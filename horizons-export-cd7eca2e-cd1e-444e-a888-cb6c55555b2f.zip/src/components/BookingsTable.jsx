import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Trash2, Tv, Tablet, Calendar, Clock, User, Book, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';

const getEquipmentIcon = (equipment) => {
  switch (equipment) {
    case 'Netbook':
      return <Tv className="h-5 w-5 mr-2 text-indigo-400" />;
    case 'Tablet':
      return <Tablet className="h-5 w-5 mr-2 text-purple-400" />;
    default:
      return null;
  }
};

const BookingsTable = ({ bookings, deleteBooking }) => {
  return (
    <motion.div
      initial={{ opacity: 0, x: 50 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.7, delay: 0.4 }}
      className="lg:col-span-3"
    >
      <Card>
        <CardHeader>
          <CardTitle>Quadro de Agendamentos</CardTitle>
          <CardDescription>Visualize todos os agendamentos confirmados.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="border rounded-lg overflow-hidden border-slate-800 max-h-[60vh] overflow-y-auto">
            <Table>
              <TableHeader className="sticky top-0 bg-slate-900/80 backdrop-blur-sm">
                <TableRow>
                  <TableHead>Detalhes</TableHead>
                  <TableHead>Professor</TableHead>
                  <TableHead>Data & Hora</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <AnimatePresence>
                  {bookings.length > 0 ? (
                    bookings.map((booking, index) => (
                      <motion.tr
                        key={booking.id}
                        layout
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, x: -50, transition: { duration: 0.3 } }}
                        transition={{ duration: 0.3, delay: index * 0.05 }}
                        className="hover:bg-slate-800/50"
                      >
                        <TableCell>
                          <div className="flex items-center font-medium">{getEquipmentIcon(booking.equipmentType)} {booking.equipmentType} ({booking.equipmentQuantity})</div>
                          <div className="text-xs text-slate-400 flex items-center mt-1"><Book className="w-3 h-3 mr-1.5"/>{booking.subject}</div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center"><User className="w-3 h-3 mr-1.5 text-purple-400"/>{booking.teacherName}</div>
                          <div className="text-xs text-slate-400 flex items-center mt-1"><Users className="w-3 h-3 mr-1.5 text-indigo-400"/>{booking.proati}</div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center"><Calendar className="w-3 h-3 mr-1.5 text-green-400"/>{new Date(booking.date).toLocaleDateString('pt-BR', {timeZone: 'UTC'})}</div>
                          <div className="text-xs text-slate-400 flex items-center mt-1"><Clock className="w-3 h-3 mr-1.5 text-yellow-400"/>{booking.period} - {booking.classTimes.map(t => `${t}ª`).join(', ')} aula(s)</div>
                        </TableCell>
                        <TableCell className="text-right">
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="ghost" size="icon" className="text-red-500 hover:text-red-400 hover:bg-red-900/20 rounded-full">
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Confirmar Exclusão</AlertDialogTitle>
                                <AlertDialogDescription>
                                  Tem certeza que deseja excluir este agendamento? Esta ação não pode ser desfeita.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                <AlertDialogAction onClick={() => deleteBooking(booking.id)} className="bg-red-600 hover:bg-red-700">Confirmar</AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </TableCell>
                      </motion.tr>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={4} className="h-48 text-center text-slate-400">
                        <div className="flex flex-col items-center justify-center">
                          <img  className="w-24 h-24 mb-4 opacity-30" alt="Calendário vazio" src="https://images.unsplash.com/photo-1606327054476-256fc9690fe2" />
                          <p>Nenhum agendamento encontrado.</p>
                          <p className="text-sm text-slate-500">Comece preenchendo o formulário ao lado.</p>
                        </div>
                      </TableCell>
                    </TableRow>
                  )}
                </AnimatePresence>
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default BookingsTable;