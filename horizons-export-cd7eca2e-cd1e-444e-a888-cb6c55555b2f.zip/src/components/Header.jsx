import React from 'react';
import { motion } from 'framer-motion';

const Header = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="w-full max-w-7xl mx-auto"
    >
      <header className="text-center mb-12 mt-8">
        <h1 className="text-4xl sm:text-6xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 via-pink-500 to-red-500">
          Agendamento Tech
        </h1>
        <p className="text-lg text-white mt-3">Reserve netbooks e tablets para suas aulas com facilidade.</p>
      </header>
    </motion.div>
  );
};

export default Header;